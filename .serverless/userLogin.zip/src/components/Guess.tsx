const Guess = () => {
  return (
    <section>
      <p>GOAT</p>
      <p>TABLE</p>
    </section>
  );
};

export default Guess;
