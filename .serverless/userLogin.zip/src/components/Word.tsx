import React from 'react';

const Word = () => {
  return (
    <section>
      <p>GLTAATOBE</p>
    </section>
  );
};

export default Word;
