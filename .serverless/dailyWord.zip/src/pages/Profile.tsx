import '../styling/pages/Profile.css';

const Profile = () => {
  return (
    <section className="profile-container">Profile Page comming soon!</section>
  );
};

export default Profile;
